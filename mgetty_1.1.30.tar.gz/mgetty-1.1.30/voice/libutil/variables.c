/*
 * variables.c
 *
 * Just defines necessary global variables.
 *
 * $Id: variables.c,v 1.2 1998/09/09 21:07:12 gert Exp $
 *
 */

#include "../include/voice.h"
#include "../include/version.h"

char POS[80];
